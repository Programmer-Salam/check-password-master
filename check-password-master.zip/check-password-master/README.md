# check-password
Bash script that checks for a strong input password by user
